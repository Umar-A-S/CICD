<?php
// FILE: admin_scholarship_management.php

// Configure session cookie parameters to improve compatibility on mobile browsers
$secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
$cookieParams = [
    'lifetime' => 0,
    'path' => '/',
    'secure' => $secure,
    'httponly' => true,
    'samesite' => 'Lax'
];
if (PHP_VERSION_ID >= 70300) {
    session_set_cookie_params($cookieParams);
} else {
    session_set_cookie_params($cookieParams['lifetime'], $cookieParams['path'], ini_get('session.cookie_domain'), $cookieParams['secure'], $cookieParams['httponly']);
}
session_start();
include 'db_connect.php';

// Cek autentikasi dan role Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$message = '';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$edit_data = null;

// --- LOGIKA CRUD ---

// A. TAMBAH/EDIT Data
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_scholarship'])) {
    $id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);
    $nama_beasiswa = trim($_POST['nama_beasiswa']);
    $min_ipk = filter_input(INPUT_POST, 'min_ipk', FILTER_VALIDATE_FLOAT);
    $min_semester = filter_input(INPUT_POST, 'min_semester', FILTER_VALIDATE_INT);

    if (empty($nama_beasiswa) || $min_ipk === false || $min_semester === false) {
        $message = "<div style='color: var(--danger-color);'>Input tidak lengkap atau tidak valid.</div>";
    } else {
        if ($id) {
            // Update
            $stmt = $conn->prepare("UPDATE scholarship_types SET nama_beasiswa = ?, min_ipk = ?, min_semester = ? WHERE id = ?");
            $stmt->bind_param("sdis", $nama_beasiswa, $min_ipk, $min_semester, $id);
            if ($stmt->execute()) {
                $message = "<div style='color: var(--success-color);'>Data beasiswa berhasil diperbarui.</div>";
            } else {
                $message = "<div style='color: var(--danger-color);'>Gagal memperbarui data: " . $stmt->error . "</div>";
            }
        } else {
            // Insert Baru
            $stmt = $conn->prepare("INSERT INTO scholarship_types (nama_beasiswa, min_ipk, min_semester) VALUES (?, ?, ?)");
            $stmt->bind_param("sdi", $nama_beasiswa, $min_ipk, $min_semester);
            if ($stmt->execute()) {
                $message = "<div style='color: var(--success-color);'>Beasiswa baru berhasil ditambahkan.</div>";
            } else {
                $message = "<div style='color: var(--danger-color);'>Gagal menambahkan data: " . $stmt->error . "</div>";
            }
        }
        $stmt->close();
        $action = 'list'; // Kembali ke tampilan list
    }
}

// B. Edit Pilihan (Ambil Data)
if ($action == 'edit' && isset($_GET['id'])) {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $stmt = $conn->prepare("SELECT * FROM scholarship_types WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $edit_data = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$edit_data) {
        $message = "<div style='color: var(--danger-color);'>Data beasiswa tidak ditemukan.</div>";
        $action = 'list';
    }
}

// C. Hapus Data
if ($action == 'delete' && isset($_GET['id'])) {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $stmt = $conn->prepare("DELETE FROM scholarship_types WHERE id = ?");
    $stmt->bind_param("i", $id);
    if ($stmt->execute()) {
        $message = "<div style='color: var(--success-color);'>Beasiswa berhasil dihapus.</div>";
    } else {
        $message = "<div style='color: var(--danger-color);'>Gagal menghapus beasiswa. Pastikan tidak ada pengajuan yang menggunakan jenis beasiswa ini.</div>";
    }
    $stmt->close();
    $action = 'list';
}

// Ambil semua data beasiswa untuk tampilan list
$scholarships = $conn->query("SELECT * FROM scholarship_types ORDER BY id ASC");

?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Beasiswa Admin</title>
    <link rel="icon" href="crown-user-svgrepo-com.svg" type="image/svg+xml">
    <style>
        :root{
            --accent-1: #667eea;
            --accent-2: #764ba2;
            --success: #10b981;
            --danger: #ef4444;
            --muted: #6c7a89;
            --bg-dark-1: #071033;
            --bg-dark-2: #0f172a;
        }

        *{box-sizing:border-box;margin:0;padding:0;text-decoration: none;}
        html,body{height:100%; background-color:var(--bg-dark-2)}
        body{
            font-family: 'Inter', system-ui, -apple-system, "Segoe UI", Roboto;
            color:#e6eefc;
            overflow-x:hidden;
        }

        .dashboard-layout{display:flex; min-height:100vh}

        .sidebar{
            position:fixed; left:0; top:0; width:260px; height:100vh;
            background:linear-gradient(180deg, rgba(15,23,42,0.95), rgba(7,16,51,0.95));
            border-right:1px solid rgba(255,255,255,0.03);
            padding-top:24px;
            z-index:100;
            overflow-y:auto;
        }

        .sidebar h3{padding:0 18px; margin-bottom:24px; font-size:18px; font-weight:700; color:#e6f0ff}

        .sidebar ul{list-style:none}
        .sidebar ul li a{
            display:block; padding:10px 18px; color:rgba(230,238,252,0.75); text-decoration:none;
            border-radius:8px; margin:3px 10px; transition:all 0.2s;
            border-left:3px solid transparent;
        }
        .sidebar ul li a:hover{background:rgba(102,126,234,0.15); color:#e6eefc}
        .sidebar ul li a.active{background:rgba(102,126,234,0.25); color:#fff; border-left-color:var(--accent-1)}

        .main-content{
            margin-left:260px; flex:1; padding:28px;
            background:radial-gradient(1200px 600px at 10% 10%, rgba(102,126,234,0.08), transparent),
                       linear-gradient(135deg, var(--bg-dark-2) 0%, var(--bg-dark-1) 100%);
        }

        .card{
            border-radius:14px;
            background:linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
            border:1px solid rgba(255,255,255,0.03);
            box-shadow:0 10px 40px rgba(2,6,23,0.6);
            padding:28px;
            margin-bottom:24px;
        }

        h2{font-size:24px; font-weight:700; color:#e6f0ff; margin-bottom:18px}
        h3{font-size:18px; font-weight:700; color:#e6f0ff; margin-bottom:14px}

        .btn{
            display:inline-flex; align-items:center; justify-content:center;
            padding:10px 16px; border-radius:10px; cursor:pointer; border:none;
            font-weight:600; text-decoration:none; transition:all 0.2s;
        }
        .btn-success{background:linear-gradient(90deg, var(--success), #059669); color:white}
        .btn-success:hover{transform:translateY(-2px); box-shadow:0 8px 20px rgba(16,185,129,0.25)}
        .btn-primary{background:linear-gradient(90deg, var(--accent-1), var(--accent-2)); color:white}
        .btn-primary:hover{transform:translateY(-2px); box-shadow:0 8px 20px rgba(102,126,234,0.25)}

        .data-table{
            width:100%; border-collapse:collapse;
            background:rgba(255,255,255,0.01);
            border-radius:10px; overflow:hidden;
            border:1px solid rgba(255,255,255,0.03);
        }
        .data-table thead{background:rgba(102,126,234,0.08); border-bottom:1px solid rgba(255,255,255,0.05)}
        .data-table th{padding:12px 14px; color:#cfe1ff; font-weight:600; text-align:left}
        .data-table td{padding:12px 14px; border-bottom:1px solid rgba(255,255,255,0.02)}
        .data-table tbody tr:hover{background:rgba(102,126,234,0.05)}
        .data-table a{color:var(--accent-1); text-decoration:none; font-weight:600}
        .data-table a:hover{text-decoration:underline}

        .form-group{margin-bottom:16px}
        .form-group label{display:block; color:#cfe1ff; font-weight:600; margin-bottom:6px}
        .form-control{
            width:100%; padding:10px 12px; border-radius:10px;
            border:1px solid rgba(255,255,255,0.04);
            background:rgba(255,255,255,0.02); color:#e6eefc;
        }
        .form-control::placeholder{color:rgba(230,238,252,0.35)}
        .form-control:focus{outline:none; border-color:var(--accent-1); box-shadow:0 0 0 3px rgba(102,126,234,0.1)}

        .message{padding:12px 14px; border-radius:10px; margin-bottom:16px}
        .message-success{background:linear-gradient(135deg, rgba(16,185,129,0.15), rgba(5,150,105,0.1)); color:#86efac; border:1px solid rgba(16,185,129,0.2)}
        .message-danger{background:linear-gradient(135deg, rgba(239,68,68,0.15), rgba(220,38,38,0.1)); color:#fca5a5; border:1px solid rgba(239,68,68,0.2)}

        @media (max-width:768px){
            .sidebar{width:180px}
            .main-content{margin-left:180px; padding:16px}
            .card{padding:16px}
        }
    </style>
</head>
<body>
    <div class="dashboard-layout">
        
        <div class="sidebar">
            <h3>Admin Panel</h3>
            <ul>
                <li><a href="dashboard_admin.php?p=dashboard">Dashboard</a></li>
                <li><a href="dashboard_admin.php?p=verification">Verifikasi Pengajuan</a></li>
                <li><a href="admin_scholarship_management.php" class="active">Manajemen Beasiswa</a></li>
                <li><a href="dashboard_admin.php?p=export_data">Export Data</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </div>
        
        <div class="main-content">
            <div class="card">
                <h2>Manajemen Jenis Beasiswa (CRUD)</h2>
                
                <?php if (!empty($message)): ?>
                    <div class="message <?php echo strpos($message, 'success') !== false ? 'message-success' : 'message-danger'; ?>">
                        <?php echo $message; ?>
                    </div>
                <?php endif; ?>

                <?php if ($action == 'list'): ?>
                    
                    <div style="margin-bottom:20px">
                        <a href="?action=add" class="btn btn-success">+ Tambah Kategori Beasiswa</a>
                    </div>
                    
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Beasiswa</th>
                                <th>Min. IPK</th>
                                <th>Min. Semester</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $scholarships->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo $row['id']; ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_beasiswa']); ?></td>
                                    <td><?php echo $row['min_ipk']; ?></td>
                                    <td><?php echo $row['min_semester']; ?></td>
                                    <td>
                                        <a href="?action=edit&id=<?php echo $row['id']; ?>">Edit</a> | 
                                        <a href="?action=delete&id=<?php echo $row['id']; ?>" style="color:var(--danger)" 
                                           onclick="return confirm('Yakin ingin menghapus beasiswa <?php echo htmlspecialchars($row['nama_beasiswa']); ?>? Data pengajuan terkait akan terpengaruh!');">Hapus</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>

                <?php elseif ($action == 'add' || $action == 'edit'): ?>

                    <h3><?php echo ($action == 'edit' ? 'Edit' : 'Tambah') . ' Jenis Beasiswa'; ?></h3>
                    <form action="admin_scholarship_management.php" method="POST">
                        <input type="hidden" name="id" value="<?php echo htmlspecialchars($edit_data['id'] ?? ''); ?>">
                        
                        <div class="form-group">
                            <label for="nama_beasiswa">Nama Beasiswa</label>
                            <input type="text" class="form-control" id="nama_beasiswa" name="nama_beasiswa" 
                                   value="<?php echo htmlspecialchars($edit_data['nama_beasiswa'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="min_ipk">Minimal IPK (Contoh: 3.00)</label>
                            <input type="number" step="0.01" class="form-control" id="min_ipk" name="min_ipk" 
                                   value="<?php echo htmlspecialchars($edit_data['min_ipk'] ?? ''); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="min_semester">Minimal Semester</label>
                            <input type="number" class="form-control" id="min_semester" name="min_semester" 
                                   value="<?php echo htmlspecialchars($edit_data['min_semester'] ?? ''); ?>" required>
                        </div>
                        
                        <div style="display:flex; gap:12px; margin-top:20px">
                            <button type="submit" name="save_scholarship" class="btn btn-primary">Simpan Data</button>
                            <a href="admin_scholarship_management.php" class="btn" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.08);">Batal</a>
                        </div>
                    </form>

                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>